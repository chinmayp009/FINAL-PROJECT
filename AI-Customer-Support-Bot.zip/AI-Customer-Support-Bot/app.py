import streamlit as st
import google.generativeai as genai

genai.configure(api_key="AQ.Ab8RN6Jo7njQFJtzF2bLChyr26IeTqJGWsVguqS8HiekgGrWHw")
model = genai.GenerativeModel("gemini-2.5-flash")
from dotenv import load_dotenv
import os

# Load API key
load_dotenv()

api_key = os.getenv("AQ.Ab8RN6Jo7njQFJtzF2bLChyr26IeTqJGWsVguqS8HiekgGrWHw")

genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))

model = genai.GenerativeModel("gemini-2.5-flash")

st.set_page_config(page_title="AI Customer Support Bot")

st.title("🤖 AI Customer Support Bot")

st.write("Ask me anything!")

# Chat history
if "messages" not in st.session_state:
    st.session_state.messages = []

# Display previous messages
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# User input
prompt = st.chat_input("Type your question...")

if prompt:

    st.session_state.messages.append(
        {"role": "user", "content": prompt}
    )

    with st.chat_message("user"):
        st.markdown(prompt)

    response = model.generate_content(prompt)

    answer = response.text

    st.session_state.messages.append(
        {"role": "assistant", "content": answer}
    )

    with st.chat_message("assistant"):
        st.markdown(answer)